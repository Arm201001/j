#!bin/bash
ndk-build